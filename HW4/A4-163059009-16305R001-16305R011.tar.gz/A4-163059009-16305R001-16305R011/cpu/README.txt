-- Training 

 th trainModel.lua -data ../../dataset/train/train_data.txt -target ../../dataset/train/train_labels.txt
 or 
 th trainModel.lua -modelName rnn_2018-03-18-11:08:56_512 -data ../../dataset/train/train_data.txt -target ../../dataset/train/train_labels.txt


-- Testing the Model
th testModel.lua -modelName bestModel/ -data ../../dataset/test/test_data.txt
